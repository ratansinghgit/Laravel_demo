
## Installation

We need composer to install all packages.

Let's install all packages, by running this command from Terminal

```
composer install
```

And run the web server

Now, visit http://localhost:8000 to try the demo.
