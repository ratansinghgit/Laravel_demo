<?php $__env->startSection('content'); ?>
  <div class="container">

    <form method="POST" action="/page">

      <div class="clearfix">
        <div class="pull-left">
          <div class="lead">
            <strong>Add new page</strong>
          </div>
        </div>
        <div class="pull-right">
          <button type="submit" class="btn btn-success">Save</button>
          <a href="/page" class="btn btn-default">Back to list</a>
        </div>
      </div>
      <hr>

      <?php echo $__env->make('page.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </form>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>