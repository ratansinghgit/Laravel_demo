<?php $__env->startSection('content'); ?>

  <div class="container">

    <h2><?php echo e($page->title); ?></h2>

    <div>
      Posted by <?php echo e($page->name); ?>

      <time class="timeago" datetime="<?php echo e($page->updated_at->toIso8601String()); ?>"
            title="<?php echo e($page->updated_at->toDayDateTimeString()); ?>">
        <?php echo e($page->updated_at->diffForHumans()); ?>

      </time>
    </div>

    <hr>

    <div>
      <?php echo $page->content; ?>

    </div>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>