<?php echo csrf_field(); ?>


<div class="form-group <?php echo e($errors->has('url') ? 'has-error' : ''); ?>">

  <label for="url" class="control-label">
    <?php echo e(trans('url')); ?>

  </label>

  <input type="url"
         name="url"
         id="url"
         value="<?php echo e(old('url', @$page->url)); ?>"
         placeholder="url"
         required
         class="form-control">

  <?php if($errors->has('url')): ?>
    <div class="help-block">
      <?php echo e($errors->first('url')); ?>

    </div>
  <?php endif; ?>
</div>

<div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">

  <label for="name" class="control-label">
    <?php echo e(trans('name')); ?>

  </label>

  <input type="text"
         name="name"
         id="name"
         value="<?php echo e(old('name', @$page->name)); ?>"
         placeholder="name"
         required
         class="form-control">

  <?php if($errors->has('name')): ?>
    <div class="help-block">
      <?php echo e($errors->first('name')); ?>

    </div>
  <?php endif; ?>
</div>

<div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">

  <label for="title" class="control-label">
    <?php echo e(trans('title')); ?>

  </label>

  <input type="text"
         name="title"
         id="title"
         value="<?php echo e(old('title', @$page->title)); ?>"
         placeholder="title"
         required
         class="form-control">

  <?php if($errors->has('title')): ?>
    <div class="help-block">
      <?php echo e($errors->first('title')); ?>

    </div>
  <?php endif; ?>
</div>

<div class="form-group <?php echo e($errors->has('content') ? 'has-error' : ''); ?>">

  <label for="content" class="control-label">
    <?php echo e(trans('content')); ?>

  </label>

      <textarea
          name="content"
          id="content"
          placeholder="content"
          required
          class="form-control"><?php echo e(old('content', @$page->content)); ?></textarea>

  <?php if($errors->has('content')): ?>
    <div class="help-block">
      <?php echo e($errors->first('content')); ?>

    </div>
  <?php endif; ?>
</div>

<div class="form-group">
  <button type="submit" class="btn btn-success">Save</button>
  <a href="/page" class="btn btn-default">Back to list</a>
</div>

